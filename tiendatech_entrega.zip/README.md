# TiendaTech

Flutter app for browsing a remote product catalog and saving one priority and
personal note per product. Product data comes from Fake Store API; notes are
stored locally with Drift first and synchronized to Firestore when available.

## Team

- Santiago Cano Duque
- Second team member: add their name before submission.

## Requirements

- Flutter SDK compatible with the Dart constraint in `pubspec.yaml`.
- Android Studio, Xcode, or another Flutter-supported device/emulator.
- Internet access to load Fake Store API products.
- A Firebase project configured for the target platform to synchronize notes.
  The application still keeps notes locally when Firebase is not configured or
  unavailable.

## Run

```bash
flutter pub get
flutter run
```

The product catalog uses `https://fakestoreapi.com/products`. The app shows
loading, success, empty, timeout, and request-error states, and provides a retry
action after errors.

## Configure Firestore note sync

1. Create or select a Firebase project and enable Cloud Firestore.
2. Configure this Flutter app with FlutterFire:

   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```

3. In `lib/main.dart`, import the generated `firebase_options.dart` and pass
   `DefaultFirebaseOptions.currentPlatform` to `Firebase.initializeApp`.
4. Run the app again. Notes are written to the local Drift database before
   Firestore is attempted. The collection is `notas`, and each document ID is
   the product ID.

## Persistence and synchronization

- Drift stores the product ID, note, priority, update time, and `pendingSync`.
- Each product uses its product ID as the note record ID, so saving again
  updates the existing record.
- The detail screen loads the saved note and sync status from Drift.
- The catalog's **Sincronizar pendientes** button retries only records with
  `pendingSync == true`.
- The UI uses `NotaRepository` for local note reads, saves, and synchronization.

## Assignment questions

1. **What is `pendingSync` for?** It marks a note that is saved locally but has
   not yet been confirmed in Firestore.
2. **Why save to Drift first?** The user's note is preserved immediately, even
   when there is no connection or Firebase is unavailable.
3. **What does the Repository do?** It gives the UI one place to read and save
   notes and coordinates local storage with remote synchronization.
4. **What happens if Firebase fails?** The local note remains saved with
   `pendingSync` set to `true`, so the user can retry synchronization later.

## Tests

```bash
flutter test
```
