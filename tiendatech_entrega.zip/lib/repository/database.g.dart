// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $NotasOfflineTable extends NotasOffline
    with TableInfo<$NotasOfflineTable, NotaOffline> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NotasOfflineTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _idProductoMeta = const VerificationMeta(
    'idProducto',
  );
  @override
  late final GeneratedColumn<int> idProducto = GeneratedColumn<int>(
    'id_producto',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _priorityMeta = const VerificationMeta(
    'priority',
  );
  @override
  late final GeneratedColumn<int> priority = GeneratedColumn<int>(
    'priority',
    aliasedName,
    false,
    check: () => ComparableExpr(priority).isBetweenValues(2, 5),
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(1),
  );
  static const VerificationMeta _textoMeta = const VerificationMeta('texto');
  @override
  late final GeneratedColumn<String> texto = GeneratedColumn<String>(
    'texto',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _pendingSyncMeta = const VerificationMeta(
    'pendingSync',
  );
  @override
  late final GeneratedColumn<bool> pendingSync = GeneratedColumn<bool>(
    'pending_sync',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("pending_sync" IN (0, 1))',
    ),
    defaultValue: const Constant(true),
  );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
    defaultValue: currentDateAndTime,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idProducto,
    priority,
    texto,
    pendingSync,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'notas_offline';
  @override
  VerificationContext validateIntegrity(
    Insertable<NotaOffline> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_producto')) {
      context.handle(
        _idProductoMeta,
        idProducto.isAcceptableOrUnknown(data['id_producto']!, _idProductoMeta),
      );
    } else if (isInserting) {
      context.missing(_idProductoMeta);
    }
    if (data.containsKey('priority')) {
      context.handle(
        _priorityMeta,
        priority.isAcceptableOrUnknown(data['priority']!, _priorityMeta),
      );
    }
    if (data.containsKey('texto')) {
      context.handle(
        _textoMeta,
        texto.isAcceptableOrUnknown(data['texto']!, _textoMeta),
      );
    } else if (isInserting) {
      context.missing(_textoMeta);
    }
    if (data.containsKey('pending_sync')) {
      context.handle(
        _pendingSyncMeta,
        pendingSync.isAcceptableOrUnknown(
          data['pending_sync']!,
          _pendingSyncMeta,
        ),
      );
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NotaOffline map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NotaOffline(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      idProducto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_producto'],
      )!,
      priority: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}priority'],
      )!,
      texto: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}texto'],
      )!,
      pendingSync: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}pending_sync'],
      )!,
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $NotasOfflineTable createAlias(String alias) {
    return $NotasOfflineTable(attachedDatabase, alias);
  }
}

class NotaOffline extends DataClass implements Insertable<NotaOffline> {
  final int id;
  final int idProducto;
  final int priority;
  final String texto;
  final bool pendingSync;
  final DateTime updatedAt;
  const NotaOffline({
    required this.id,
    required this.idProducto,
    required this.priority,
    required this.texto,
    required this.pendingSync,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['id_producto'] = Variable<int>(idProducto);
    map['priority'] = Variable<int>(priority);
    map['texto'] = Variable<String>(texto);
    map['pending_sync'] = Variable<bool>(pendingSync);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  NotasOfflineCompanion toCompanion(bool nullToAbsent) {
    return NotasOfflineCompanion(
      id: Value(id),
      idProducto: Value(idProducto),
      priority: Value(priority),
      texto: Value(texto),
      pendingSync: Value(pendingSync),
      updatedAt: Value(updatedAt),
    );
  }

  factory NotaOffline.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NotaOffline(
      id: serializer.fromJson<int>(json['id']),
      idProducto: serializer.fromJson<int>(json['idProducto']),
      priority: serializer.fromJson<int>(json['priority']),
      texto: serializer.fromJson<String>(json['texto']),
      pendingSync: serializer.fromJson<bool>(json['pendingSync']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'idProducto': serializer.toJson<int>(idProducto),
      'priority': serializer.toJson<int>(priority),
      'texto': serializer.toJson<String>(texto),
      'pendingSync': serializer.toJson<bool>(pendingSync),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  NotaOffline copyWith({
    int? id,
    int? idProducto,
    int? priority,
    String? texto,
    bool? pendingSync,
    DateTime? updatedAt,
  }) => NotaOffline(
    id: id ?? this.id,
    idProducto: idProducto ?? this.idProducto,
    priority: priority ?? this.priority,
    texto: texto ?? this.texto,
    pendingSync: pendingSync ?? this.pendingSync,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  NotaOffline copyWithCompanion(NotasOfflineCompanion data) {
    return NotaOffline(
      id: data.id.present ? data.id.value : this.id,
      idProducto: data.idProducto.present
          ? data.idProducto.value
          : this.idProducto,
      priority: data.priority.present ? data.priority.value : this.priority,
      texto: data.texto.present ? data.texto.value : this.texto,
      pendingSync: data.pendingSync.present
          ? data.pendingSync.value
          : this.pendingSync,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NotaOffline(')
          ..write('id: $id, ')
          ..write('idProducto: $idProducto, ')
          ..write('priority: $priority, ')
          ..write('texto: $texto, ')
          ..write('pendingSync: $pendingSync, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idProducto, priority, texto, pendingSync, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NotaOffline &&
          other.id == this.id &&
          other.idProducto == this.idProducto &&
          other.priority == this.priority &&
          other.texto == this.texto &&
          other.pendingSync == this.pendingSync &&
          other.updatedAt == this.updatedAt);
}

class NotasOfflineCompanion extends UpdateCompanion<NotaOffline> {
  final Value<int> id;
  final Value<int> idProducto;
  final Value<int> priority;
  final Value<String> texto;
  final Value<bool> pendingSync;
  final Value<DateTime> updatedAt;
  const NotasOfflineCompanion({
    this.id = const Value.absent(),
    this.idProducto = const Value.absent(),
    this.priority = const Value.absent(),
    this.texto = const Value.absent(),
    this.pendingSync = const Value.absent(),
    this.updatedAt = const Value.absent(),
  });
  NotasOfflineCompanion.insert({
    this.id = const Value.absent(),
    required int idProducto,
    this.priority = const Value.absent(),
    required String texto,
    this.pendingSync = const Value.absent(),
    this.updatedAt = const Value.absent(),
  }) : idProducto = Value(idProducto),
       texto = Value(texto);
  static Insertable<NotaOffline> custom({
    Expression<int>? id,
    Expression<int>? idProducto,
    Expression<int>? priority,
    Expression<String>? texto,
    Expression<bool>? pendingSync,
    Expression<DateTime>? updatedAt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProducto != null) 'id_producto': idProducto,
      if (priority != null) 'priority': priority,
      if (texto != null) 'texto': texto,
      if (pendingSync != null) 'pending_sync': pendingSync,
      if (updatedAt != null) 'updated_at': updatedAt,
    });
  }

  NotasOfflineCompanion copyWith({
    Value<int>? id,
    Value<int>? idProducto,
    Value<int>? priority,
    Value<String>? texto,
    Value<bool>? pendingSync,
    Value<DateTime>? updatedAt,
  }) {
    return NotasOfflineCompanion(
      id: id ?? this.id,
      idProducto: idProducto ?? this.idProducto,
      priority: priority ?? this.priority,
      texto: texto ?? this.texto,
      pendingSync: pendingSync ?? this.pendingSync,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProducto.present) {
      map['id_producto'] = Variable<int>(idProducto.value);
    }
    if (priority.present) {
      map['priority'] = Variable<int>(priority.value);
    }
    if (texto.present) {
      map['texto'] = Variable<String>(texto.value);
    }
    if (pendingSync.present) {
      map['pending_sync'] = Variable<bool>(pendingSync.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NotasOfflineCompanion(')
          ..write('id: $id, ')
          ..write('idProducto: $idProducto, ')
          ..write('priority: $priority, ')
          ..write('texto: $texto, ')
          ..write('pendingSync: $pendingSync, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $NotasOfflineTable notasOffline = $NotasOfflineTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [notasOffline];
}

typedef $$NotasOfflineTableCreateCompanionBuilder =
    NotasOfflineCompanion Function({
      Value<int> id,
      required int idProducto,
      Value<int> priority,
      required String texto,
      Value<bool> pendingSync,
      Value<DateTime> updatedAt,
    });
typedef $$NotasOfflineTableUpdateCompanionBuilder =
    NotasOfflineCompanion Function({
      Value<int> id,
      Value<int> idProducto,
      Value<int> priority,
      Value<String> texto,
      Value<bool> pendingSync,
      Value<DateTime> updatedAt,
    });

class $$NotasOfflineTableFilterComposer
    extends Composer<_$AppDatabase, $NotasOfflineTable> {
  $$NotasOfflineTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idProducto => $composableBuilder(
    column: $table.idProducto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get priority => $composableBuilder(
    column: $table.priority,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get texto => $composableBuilder(
    column: $table.texto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get pendingSync => $composableBuilder(
    column: $table.pendingSync,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$NotasOfflineTableOrderingComposer
    extends Composer<_$AppDatabase, $NotasOfflineTable> {
  $$NotasOfflineTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idProducto => $composableBuilder(
    column: $table.idProducto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get priority => $composableBuilder(
    column: $table.priority,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get texto => $composableBuilder(
    column: $table.texto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get pendingSync => $composableBuilder(
    column: $table.pendingSync,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$NotasOfflineTableAnnotationComposer
    extends Composer<_$AppDatabase, $NotasOfflineTable> {
  $$NotasOfflineTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idProducto => $composableBuilder(
    column: $table.idProducto,
    builder: (column) => column,
  );

  GeneratedColumn<int> get priority =>
      $composableBuilder(column: $table.priority, builder: (column) => column);

  GeneratedColumn<String> get texto =>
      $composableBuilder(column: $table.texto, builder: (column) => column);

  GeneratedColumn<bool> get pendingSync => $composableBuilder(
    column: $table.pendingSync,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$NotasOfflineTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $NotasOfflineTable,
          NotaOffline,
          $$NotasOfflineTableFilterComposer,
          $$NotasOfflineTableOrderingComposer,
          $$NotasOfflineTableAnnotationComposer,
          $$NotasOfflineTableCreateCompanionBuilder,
          $$NotasOfflineTableUpdateCompanionBuilder,
          (
            NotaOffline,
            BaseReferences<_$AppDatabase, $NotasOfflineTable, NotaOffline>,
          ),
          NotaOffline,
          PrefetchHooks Function()
        > {
  $$NotasOfflineTableTableManager(_$AppDatabase db, $NotasOfflineTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$NotasOfflineTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$NotasOfflineTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$NotasOfflineTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<int> idProducto = const Value.absent(),
                Value<int> priority = const Value.absent(),
                Value<String> texto = const Value.absent(),
                Value<bool> pendingSync = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
              }) => NotasOfflineCompanion(
                id: id,
                idProducto: idProducto,
                priority: priority,
                texto: texto,
                pendingSync: pendingSync,
                updatedAt: updatedAt,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required int idProducto,
                Value<int> priority = const Value.absent(),
                required String texto,
                Value<bool> pendingSync = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
              }) => NotasOfflineCompanion.insert(
                id: id,
                idProducto: idProducto,
                priority: priority,
                texto: texto,
                pendingSync: pendingSync,
                updatedAt: updatedAt,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$NotasOfflineTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $NotasOfflineTable,
      NotaOffline,
      $$NotasOfflineTableFilterComposer,
      $$NotasOfflineTableOrderingComposer,
      $$NotasOfflineTableAnnotationComposer,
      $$NotasOfflineTableCreateCompanionBuilder,
      $$NotasOfflineTableUpdateCompanionBuilder,
      (
        NotaOffline,
        BaseReferences<_$AppDatabase, $NotasOfflineTable, NotaOffline>,
      ),
      NotaOffline,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$NotasOfflineTableTableManager get notasOffline =>
      $$NotasOfflineTableTableManager(_db, _db.notasOffline);
}
